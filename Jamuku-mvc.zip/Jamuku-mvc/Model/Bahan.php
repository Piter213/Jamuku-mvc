<?php
class Bahan {
    private static function connect() {
        return new PDO("sqlite:" . __DIR__ . "/../database/jamuku.db");
    }

    public static function all() {
        $db = self::connect();
        $stmt = $db->query("SELECT * FROM bahan");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function find($id) {
        $db = self::connect();
        $stmt = $db->prepare("SELECT * FROM bahan WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public static function create($data) {
        $db = self::connect();
        $stmt = $db->prepare("INSERT INTO bahan (nama, deskripsi, harga, jenis) VALUES (?, ?, ?, ?)");
        return $stmt->execute([$data['nama'], $data['deskripsi'], $data['harga'], $data['jenis']]);
    }

    public static function update($id, $data) {
        $db = self::connect();
        $stmt = $db->prepare("UPDATE bahan SET nama = ?, deskripsi = ?, harga = ?, jenis = ? WHERE id = ?");
        return $stmt->execute([$data['nama'], $data['deskripsi'], $data['harga'], $data['jenis'], $id]);
    }

    public static function delete($id) {
        $db = self::connect();
        $stmt = $db->prepare("DELETE FROM bahan WHERE id = ?");
        return $stmt->execute([$id]);
    }
}
?>
