<?php
require_once 'router.php';
require_once 'Controller/BahanController.php';

$controller = new BahanController();

get('/', function() use ($controller) {
    $controller->index();
});

get('/bahan', function() use ($controller) {
    $controller->index();
});

get('/bahan/$id', function($id) use ($controller) {
    $controller->show($id);
});

get('/bahan/$id/edit', function($id) use ($controller) {
    $controller->edit($id);
});

post('/bahan/$id/update', function($id) use ($controller) {
    $controller->update($id);
});

get('/bahan/$id/delete', function($id) use ($controller) {
    $controller->delete($id);
});

get('/tambah', function() use ($controller) {
    $controller->create();
});

post('/store', function() use ($controller) {
    $controller->store();
});
?>
