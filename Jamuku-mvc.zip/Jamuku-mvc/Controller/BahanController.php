<?php
require_once __DIR__ . '/../Model/Bahan.php';

class BahanController {

    public function index() {
        $data = Bahan::all();
        include __DIR__ . '/../View/list.php';
    }

    public function show($id) {
        $bahan = Bahan::find($id);
        if ($bahan) {
            include __DIR__ . '/../View/detail.php';
        } else {
            include __DIR__ . '/../View/404.php';
        }
    }

    public function create() {
        include __DIR__ . '/../View/tambah.php';
    }

    public function store() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            Bahan::create($_POST);
            header('Location: /bahan');
            exit;
        }
    }

    public function edit($id) {
        $bahan = Bahan::find($id);
        if ($bahan) {
            include __DIR__ . '/../View/edit.php';
        } else {
            include __DIR__ . '/../View/404.php';
        }
    }

    public function update($id) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            Bahan::update($id, $_POST);
            header('Location: /bahan');
            exit;
        }
    }

    public function delete($id) {
        Bahan::delete($id);
        header('Location: /bahan');
        exit;
    }
}
?>
