<h1>Tambah Bahan Jamu</h1>

<form method="POST" action="/store">
    <p>
        <label>Nama:</label><br>
        <input type="text" name="nama" required>
    </p>
    <p>
        <label>Jenis:</label><br>
        <input type="text" name="jenis" required>
    </p>
    <p>
        <label>Harga:</label><br>
        <input type="number" name="harga" required>
    </p>
    <p>
        <label>Deskripsi:</label><br>
        <textarea name="deskripsi" required></textarea>
    </p>
    <p>
        <button type="submit">Simpan</button>
        <a href="/bahan">Batal</a>
    </p>
</form>
