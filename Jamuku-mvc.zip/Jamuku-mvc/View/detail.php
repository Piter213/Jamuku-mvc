<h1>Detail Bahan: <?php echo $bahan['nama']; ?></h1>

<p><strong>Jenis:</strong> <?php echo $bahan['jenis']; ?></p>
<p><strong>Harga:</strong> Rp <?php echo number_format($bahan['harga'], 0, ',', '.'); ?></p>
<p><strong>Deskripsi:</strong> <?php echo $bahan['deskripsi']; ?></p>

<p><a href="/bahan">Kembali</a></p>
