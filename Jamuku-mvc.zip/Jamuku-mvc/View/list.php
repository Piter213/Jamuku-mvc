<h1>Daftar Bahan Jamu</h1>
<p><a href="/tambah">+ Tambah Bahan</a></p>

<?php if (empty($data)): ?>
    <p>Belum ada data bahan.</p>
<?php else: ?>
    <table border="1" cellpadding="8" cellspacing="0">
        <thead>
            <tr>
                <th>Nama</th>
                <th>Jenis</th>
                <th>Harga</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($data as $bahan): ?>
                <tr>
                    <td><?php echo $bahan['nama']; ?></td>
                    <td><?php echo $bahan['jenis']; ?></td>
                    <td>Rp <?php echo number_format($bahan['harga'], 0, ',', '.'); ?></td>
                    <td>
                        <a href="/bahan/<?php echo $bahan['id']; ?>">Detail</a> |
                        <a href="/bahan/<?php echo $bahan['id']; ?>/edit">Edit</a> |
                        <a href="/bahan/<?php echo $bahan['id']; ?>/delete" onclick="return confirm('Yakin hapus data ini?')">Hapus</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>
