<h1>Edit Bahan Jamu</h1>

<form method="POST" action="/bahan/<?php echo $bahan['id']; ?>/update">
    <p>
        <label>Nama:</label><br>
        <input type="text" name="nama" value="<?php echo $bahan['nama']; ?>" required>
    </p>
    <p>
        <label>Jenis:</label><br>
        <input type="text" name="jenis" value="<?php echo $bahan['jenis']; ?>" required>
    </p>
    <p>
        <label>Harga:</label><br>
        <input type="number" name="harga" value="<?php echo $bahan['harga']; ?>" required>
    </p>
    <p>
        <label>Deskripsi:</label><br>
        <textarea name="deskripsi" required><?php echo $bahan['deskripsi']; ?></textarea>
    </p>
    <p>
        <button type="submit">Update</button>
        <a href="/bahan">Batal</a>
    </p>
</form>
